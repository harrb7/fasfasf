/*
  # Create User Data Storage Table

  1. New Tables
    - `user_data`
      - `id` (uuid, primary key)
      - `license_key` (text, unique) - The user's license key
      - `home_team_name` (text) - Home team name
      - `home_team_score` (integer) - Home team score
      - `away_team_name` (text) - Away team name
      - `away_team_score` (integer) - Away team score
      - `home_team_logo` (text) - Home team logo URL
      - `away_team_logo` (text) - Away team logo URL
      - `created_at` (timestamptz) - When the record was created
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on `user_data` table
    - Add policy for users to manage their own data based on license key
*/

CREATE TABLE IF NOT EXISTS user_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_key text UNIQUE NOT NULL,
  home_team_name text DEFAULT '',
  home_team_score integer DEFAULT 0,
  away_team_name text DEFAULT '',
  away_team_score integer DEFAULT 0,
  home_team_logo text DEFAULT '',
  away_team_logo text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_data ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own data by license key"
  ON user_data
  FOR SELECT
  USING (true);

CREATE POLICY "Users can insert own data"
  ON user_data
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update own data by license key"
  ON user_data
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete own data"
  ON user_data
  FOR DELETE
  USING (true);