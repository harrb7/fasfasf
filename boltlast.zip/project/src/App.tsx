import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HomePage from './components/HomePage';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import SubscriptionsPage from './components/SubscriptionsPage';
import AboutPage from './components/AboutPage';

type Page = 'home' | 'login' | 'dashboard' | 'subscriptions' | 'about';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [licenseKey, setLicenseKey] = useState('');

  useEffect(() => {
    const savedKey = localStorage.getItem('thumbscore_license_key');
    if (savedKey) {
      setLicenseKey(savedKey);
      setIsLoggedIn(true);
      setCurrentPage('dashboard');
    }
  }, []);

  const handleLoginSuccess = (key: string) => {
    setLicenseKey(key);
    setIsLoggedIn(true);
    localStorage.setItem('thumbscore_license_key', key);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setLicenseKey('');
    localStorage.removeItem('thumbscore_license_key');
    setCurrentPage('login');
  };

  const handleNavigate = (page: string) => {
    if (page === 'dashboard' && !isLoggedIn) {
      setCurrentPage('login');
    } else {
      setCurrentPage(page as Page);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Navbar
        onNavigate={handleNavigate}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
      />

      <main className="flex-grow pt-24 relative container mx-auto px-4 flex items-center justify-center min-h-screen">
        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
        {currentPage === 'login' && <LoginPage onLoginSuccess={handleLoginSuccess} />}
        {currentPage === 'dashboard' && isLoggedIn && (
          <Dashboard licenseKey={licenseKey} onLogout={handleLogout} />
        )}
        {currentPage === 'subscriptions' && <SubscriptionsPage onNavigate={handleNavigate} />}
        {currentPage === 'about' && <AboutPage />}
      </main>
    </div>
  );
}

export default App;
