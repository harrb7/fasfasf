import { Globe } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="flex flex-col items-center max-w-3xl text-center animate-fade-in">
      <div className="bg-gray-800 p-10 rounded-3xl border border-gray-700 shadow-2xl">
        <Globe className="text-blue-500 mx-auto mb-6" size={56} />
        <h2 className="text-3xl font-bold mb-6">About ThumbScore</h2>
        <p className="text-gray-300 text-lg leading-relaxed mb-8">
          ThumbScore is the premier industry tool designed to streamline the creation of
          professional sports match cards. Whether you are covering international country matchups
          or club leagues, our engine allows you to generate high-fidelity, visually stunning
          scorecards in milliseconds. We combine aesthetic precision with speed, ensuring your
          content always looks top-tier without the hassle of manual design.
        </p>

        <div className="w-full h-px bg-gray-700 mb-8"></div>

        <h3 className="text-xl font-semibold mb-6">Contact Support to Purchase</h3>
        <div className="flex flex-col md:flex-row gap-4 justify-center w-full">
          <a
            href="https://t.me/h1rbb"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-[#229ED9] hover:bg-[#1a8bc4] text-white py-3 px-6 rounded-lg transition flex items-center justify-center font-medium"
          >
            Telegram
          </a>
          <a
            href="https://wa.me/201013390833"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-[#25D366] hover:bg-[#20bd5a] text-white py-3 px-6 rounded-lg transition flex items-center justify-center font-medium"
          >
            WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}
