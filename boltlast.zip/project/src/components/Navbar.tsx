import { ThumbsUp } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: string) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
}

export default function Navbar({ onNavigate, isLoggedIn, onLogout }: NavbarProps) {
  return (
    <nav className="w-full p-6 flex justify-between items-center z-50 fixed top-0 bg-gray-900/90 backdrop-blur-md border-b border-gray-800">
      <div
        className="text-2xl font-bold tracking-wider text-white cursor-pointer flex items-center"
        onClick={() => onNavigate('home')}
      >
        <ThumbsUp className="text-blue-500 mr-2" size={28} />
        Thumb<span className="text-blue-500">Score</span>
      </div>
      <div className="space-x-8 hidden md:flex items-center">
        <button
          onClick={() => onNavigate('home')}
          className="hover:text-blue-400 transition font-medium"
        >
          Home
        </button>
        <button
          onClick={() => onNavigate('subscriptions')}
          className="hover:text-blue-400 transition font-medium"
        >
          Subscriptions
        </button>
        <button
          onClick={() => onNavigate('about')}
          className="hover:text-blue-400 transition font-medium"
        >
          About
        </button>
        {isLoggedIn ? (
          <button
            onClick={onLogout}
            className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full transition shadow-lg"
          >
            Logout
          </button>
        ) : (
          <button
            onClick={() => onNavigate('login')}
            className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-full transition shadow-lg shadow-blue-500/30"
          >
            Login
          </button>
        )}
      </div>
    </nav>
  );
}
