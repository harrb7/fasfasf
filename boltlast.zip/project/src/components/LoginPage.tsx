import { useState } from 'react';
import { Lock, Loader2, Unlock } from 'lucide-react';
import { keyAuthService } from '../lib/keyauth';

interface LoginPageProps {
  onLoginSuccess: (licenseKey: string) => void;
}

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [licenseKey, setLicenseKey] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [statusType, setStatusType] = useState<'success' | 'error' | ''>('');

  const handleLogin = async () => {
    if (!licenseKey.trim()) {
      setStatusMessage('Please enter a license key.');
      setStatusType('error');
      return;
    }

    setIsLoading(true);
    setStatusMessage('');

    try {
      const result = await keyAuthService.login(licenseKey);

      if (result.success) {
        setStatusMessage('Access Granted!');
        setStatusType('success');
        setTimeout(() => {
          onLoginSuccess(licenseKey);
        }, 500);
      } else {
        setStatusMessage(result.message || 'Login failed. Please check your license key.');
        setStatusType('error');
      }
    } catch (error) {
      setStatusMessage('An error occurred. Please try again.');
      setStatusType('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !isLoading) {
      handleLogin();
    }
  };

  return (
    <div className="flex flex-col items-center w-full animate-fade-in">
      <div className="bg-gray-800 p-8 rounded-2xl border border-gray-700 w-full max-w-md shadow-2xl">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center shadow-lg shadow-blue-500/50">
            <Lock className="text-white" size={28} />
          </div>
        </div>

        <h2 className="text-center text-3xl font-bold mb-1">ThumbScore</h2>
        <p className="text-center text-gray-400 text-sm mb-8">Enter your license key</p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wider">
              License Key
            </label>
            <input
              type="text"
              value={licenseKey}
              onChange={(e) => setLicenseKey(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Paste your license key"
              disabled={isLoading}
              className="w-full p-3 rounded-lg text-white placeholder-gray-500 bg-gray-900/80 border border-gray-600 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/50 transition outline-none"
            />
          </div>

          <button
            onClick={handleLogin}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white py-3 rounded-lg font-bold transition shadow-lg mt-4 flex justify-center items-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 animate-spin" size={20} />
                Checking...
              </>
            ) : (
              <>
                <Unlock className="mr-2" size={20} />
                Unlock
              </>
            )}
          </button>

          {statusMessage && (
            <div
              className={`text-center text-sm mt-4 font-bold ${
                statusType === 'success' ? 'text-green-400' : 'text-red-500'
              }`}
            >
              {statusMessage}
            </div>
          )}
        </div>

        <div className="mt-8 pt-6 border-t border-gray-700 text-center">
          <p className="text-gray-400 text-sm mb-4">Need a license key?</p>
          <div className="space-y-2">
            <a
              href="https://t.me/h1rbb"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-[#229ED9] hover:opacity-90 text-white text-sm font-bold py-2 rounded transition"
            >
              Contact on Telegram
            </a>
            <a
              href="https://wa.me/201013390833"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-[#25D366] hover:opacity-90 text-white text-sm font-bold py-2 rounded transition"
            >
              Contact on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
