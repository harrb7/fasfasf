import { useState, useEffect } from 'react';
import { Zap, Wand2, Plus } from 'lucide-react';
import { saveUserData, loadUserData, type UserData } from '../lib/supabase';

interface DashboardProps {
  licenseKey: string;
  onLogout: () => void;
}

export default function Dashboard({ licenseKey, onLogout }: DashboardProps) {
  const [homeTeamName, setHomeTeamName] = useState('');
  const [homeTeamScore, setHomeTeamScore] = useState(0);
  const [awayTeamName, setAwayTeamName] = useState('');
  const [awayTeamScore, setAwayTeamScore] = useState(0);
  const [homeTeamLogo, setHomeTeamLogo] = useState('');
  const [awayTeamLogo, setAwayTeamLogo] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, [licenseKey]);

  useEffect(() => {
    const saveTimer = setTimeout(() => {
      saveData();
    }, 1000);

    return () => clearTimeout(saveTimer);
  }, [homeTeamName, homeTeamScore, awayTeamName, awayTeamScore, homeTeamLogo, awayTeamLogo]);

  const loadData = async () => {
    const data = await loadUserData(licenseKey);
    if (data) {
      setHomeTeamName(data.home_team_name);
      setHomeTeamScore(data.home_team_score);
      setAwayTeamName(data.away_team_name);
      setAwayTeamScore(data.away_team_score);
      setHomeTeamLogo(data.home_team_logo);
      setAwayTeamLogo(data.away_team_logo);
    }
  };

  const saveData = async () => {
    setIsSaving(true);
    const userData: UserData = {
      license_key: licenseKey,
      home_team_name: homeTeamName,
      home_team_score: homeTeamScore,
      away_team_name: awayTeamName,
      away_team_score: awayTeamScore,
      home_team_logo: homeTeamLogo,
      away_team_logo: awayTeamLogo,
    };

    await saveUserData(userData);
    setTimeout(() => setIsSaving(false), 500);
  };

  const handleGenerateCard = () => {
    alert('Match card generation feature coming soon!');
  };

  const handleAnalyzeThumbnail = () => {
    alert('AI thumbnail analysis feature coming soon!');
  };

  return (
    <div className="flex flex-col w-full max-w-6xl animate-fade-in">
      <div className="flex justify-between items-center mb-10 border-b border-gray-700 pb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Match Generator</h1>
          <p className="text-gray-400">Create your match card below</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-sm text-gray-400">Status</div>
            <div className="flex items-center text-green-400 font-bold text-sm">
              <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
              Active {isSaving && '(Saving...)'}
            </div>
          </div>
          <button
            onClick={onLogout}
            className="bg-red-500/10 text-red-400 border border-red-500/50 px-4 py-2 rounded-lg hover:bg-red-500/20 transition text-sm"
          >
            Logout
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700 flex flex-col items-center">
          <div className="w-full text-center mb-4 font-bold text-blue-400">HOME TEAM</div>
          <div className="w-32 h-32 bg-gray-900 rounded-full flex items-center justify-center border-2 border-dashed border-gray-600 mb-4 cursor-pointer hover:border-blue-500 transition overflow-hidden group">
            {homeTeamLogo ? (
              <img src={homeTeamLogo} alt="Home Team" className="w-full h-full object-cover" />
            ) : (
              <Plus className="text-gray-500 group-hover:text-blue-500 transition" size={32} />
            )}
          </div>
          <input
            type="text"
            value={homeTeamName}
            onChange={(e) => setHomeTeamName(e.target.value)}
            placeholder="Team Name"
            className="bg-gray-900 text-white p-2 rounded text-center w-full mb-2 border border-gray-700 focus:border-blue-500 outline-none transition"
          />
          <input
            type="number"
            value={homeTeamScore}
            onChange={(e) => setHomeTeamScore(Number(e.target.value))}
            placeholder="0"
            className="bg-gray-900 text-white p-2 rounded text-center w-20 text-2xl font-bold border border-gray-700 focus:border-blue-500 outline-none transition"
          />
        </div>

        <div className="flex flex-col justify-center items-center gap-6">
          <div className="text-6xl font-black italic text-gray-700 select-none">VS</div>

          <button
            onClick={handleGenerateCard}
            className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white py-4 rounded-xl font-bold shadow-xl shadow-blue-500/20 transform hover:scale-105 transition flex items-center justify-center"
          >
            <Zap className="mr-2" size={20} />
            GENERATE CARD
          </button>

          <button
            onClick={handleAnalyzeThumbnail}
            className="w-full bg-gray-800 border border-gray-600 hover:bg-gray-700 text-white py-3 rounded-xl font-medium transition flex items-center justify-center"
          >
            <Wand2 className="mr-2" size={20} />
            AI Analyze Thumbnail
          </button>
        </div>

        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700 flex flex-col items-center">
          <div className="w-full text-center mb-4 font-bold text-red-400">AWAY TEAM</div>
          <div className="w-32 h-32 bg-gray-900 rounded-full flex items-center justify-center border-2 border-dashed border-gray-600 mb-4 cursor-pointer hover:border-red-500 transition overflow-hidden group">
            {awayTeamLogo ? (
              <img src={awayTeamLogo} alt="Away Team" className="w-full h-full object-cover" />
            ) : (
              <Plus className="text-gray-500 group-hover:text-red-500 transition" size={32} />
            )}
          </div>
          <input
            type="text"
            value={awayTeamName}
            onChange={(e) => setAwayTeamName(e.target.value)}
            placeholder="Team Name"
            className="bg-gray-900 text-white p-2 rounded text-center w-full mb-2 border border-gray-700 focus:border-red-500 outline-none transition"
          />
          <input
            type="number"
            value={awayTeamScore}
            onChange={(e) => setAwayTeamScore(Number(e.target.value))}
            placeholder="0"
            className="bg-gray-900 text-white p-2 rounded text-center w-20 text-2xl font-bold border border-gray-700 focus:border-red-500 outline-none transition"
          />
        </div>
      </div>
    </div>
  );
}
