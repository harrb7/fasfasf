import { Check, Zap } from 'lucide-react';

interface SubscriptionsPageProps {
  onNavigate: (page: string) => void;
}

export default function SubscriptionsPage({ onNavigate }: SubscriptionsPageProps) {
  return (
    <div className="w-full flex flex-col items-center animate-fade-in">
      <h2 className="text-4xl font-bold mb-12 text-center">Choose Your Plan</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl">
        <div className="bg-gray-800 p-8 rounded-2xl border border-gray-700 relative overflow-hidden group hover:transform hover:-translate-y-2 transition-all duration-300">
          <div className="absolute top-0 right-0 bg-gray-700 text-xs font-bold px-3 py-1 rounded-bl-lg">
            STARTER
          </div>
          <h3 className="text-2xl font-bold mb-2">3 Days</h3>
          <div className="text-4xl font-bold text-blue-400 mb-6">$1.00</div>
          <ul className="text-gray-400 space-y-3 mb-8 text-sm">
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />
              Full Access
            </li>
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />2 Devices
            </li>
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />
              Unlimited Cards
            </li>
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />
              Thumbnail Analyser
            </li>
          </ul>
          <button
            onClick={() => onNavigate('about')}
            className="w-full bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg transition font-semibold"
          >
            Purchase
          </button>
        </div>

        <div className="bg-gray-800 p-8 rounded-2xl border border-blue-500/50 relative overflow-hidden transform scale-105 shadow-2xl shadow-blue-900/20">
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-400 to-cyan-300"></div>
          <div className="absolute top-0 right-0 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
            BEGINNER
          </div>
          <h3 className="text-2xl font-bold mb-2">1 Week</h3>
          <div className="text-4xl font-bold text-blue-400 mb-6">$3.00</div>
          <ul className="text-gray-300 space-y-3 mb-8 text-sm">
            <li className="flex items-center">
              <Check className="text-blue-400 mr-2" size={18} />
              Full Access
            </li>
            <li className="flex items-center">
              <Check className="text-blue-400 mr-2" size={18} />2 Devices
            </li>
            <li className="flex items-center">
              <Check className="text-blue-400 mr-2" size={18} />
              Unlimited Cards
            </li>
            <li className="flex items-center">
              <Check className="text-blue-400 mr-2" size={18} />
              Thumbnail Analyser
            </li>
          </ul>
          <button
            onClick={() => onNavigate('about')}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-lg transition font-semibold shadow-lg shadow-blue-500/40 flex items-center justify-center"
          >
            <Zap className="mr-2" size={18} />
            Purchase
          </button>
        </div>

        <div className="bg-gray-800 p-8 rounded-2xl border border-gray-700 relative overflow-hidden group hover:transform hover:-translate-y-2 transition-all duration-300">
          <div className="absolute top-0 right-0 bg-green-500 text-gray-900 text-xs font-bold px-3 py-1 rounded-bl-lg">
            BEST VALUE
          </div>
          <h3 className="text-2xl font-bold mb-2">1 Month</h3>
          <div className="flex items-baseline mb-6">
            <span className="text-4xl font-bold text-blue-400 mr-3">$4.99</span>
            <span className="text-xl text-gray-500 line-through decoration-red-500 decoration-2">
              $15.00
            </span>
          </div>
          <ul className="text-gray-400 space-y-3 mb-8 text-sm">
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />
              Full Access
            </li>
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />2 Devices
            </li>
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />
              Unlimited Cards
            </li>
            <li className="flex items-center">
              <Check className="text-green-400 mr-2" size={18} />
              Thumbnail Analyser
            </li>
          </ul>
          <button
            onClick={() => onNavigate('about')}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white py-3 rounded-lg transition font-semibold"
          >
            Purchase Sale
          </button>
        </div>
      </div>
    </div>
  );
}
