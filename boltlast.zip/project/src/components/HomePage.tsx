import { Rocket, ChevronRight } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="flex flex-col items-center text-center max-w-4xl animate-fade-in">
      <div className="mb-6 inline-block px-4 py-1 bg-blue-900/30 border border-blue-500/30 rounded-full text-blue-400 text-sm font-semibold tracking-wide">
        V 1.0 NOW AVAILABLE
      </div>
      <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
        Create Viral <br />
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
          Match Cards
        </span>{' '}
        Instantly
      </h1>
      <p className="text-gray-400 text-lg mb-10 max-w-2xl mx-auto">
        ThumbScore uses advanced AI analysis to help you generate high-converting thumbnails and
        match scores for countries and clubs in seconds.
      </p>
      <div className="flex flex-col md:flex-row gap-4 justify-center">
        <button
          onClick={() => onNavigate('subscriptions')}
          className="bg-white text-gray-900 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition flex items-center justify-center group"
        >
          <Rocket className="mr-2" size={20} />
          Get Started
          <ChevronRight className="ml-1 group-hover:translate-x-1 transition-transform" size={20} />
        </button>
        <button
          onClick={() => onNavigate('about')}
          className="bg-blue-600/20 border border-blue-500/50 text-blue-400 px-8 py-3 rounded-lg font-bold hover:bg-blue-600/30 transition"
        >
          Learn More
        </button>
      </div>
    </div>
  );
}
