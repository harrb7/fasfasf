declare global {
  interface Window {
    KeyAuth: any;
  }
}

export class KeyAuthService {
  private keyAuth: any;
  private static instance: KeyAuthService;

  private constructor() {
    if (typeof window !== 'undefined' && window.KeyAuth) {
      this.keyAuth = new window.KeyAuth({
        name: "Thumbscore",
        ownerid: "FYkAfUvtKZ",
        version: "1.0",
      });
    }
  }

  static getInstance(): KeyAuthService {
    if (!KeyAuthService.instance) {
      KeyAuthService.instance = new KeyAuthService();
    }
    return KeyAuthService.instance;
  }

  async init(): Promise<void> {
    if (this.keyAuth) {
      return new Promise((resolve) => {
        this.keyAuth.init();
        setTimeout(resolve, 100);
      });
    }
  }

  async login(licenseKey: string): Promise<{ success: boolean; message: string; user?: any }> {
    try {
      if (!this.keyAuth) {
        return { success: false, message: 'KeyAuth not initialized' };
      }

      await this.init();

      return new Promise((resolve) => {
        this.keyAuth.license(licenseKey);

        setTimeout(() => {
          if (this.keyAuth.response && this.keyAuth.response.success) {
            resolve({
              success: true,
              message: 'Login successful',
              user: this.keyAuth.response.info
            });
          } else {
            resolve({
              success: false,
              message: this.keyAuth.response?.message || 'Invalid license key'
            });
          }
        }, 1500);
      });
    } catch (error) {
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Login failed'
      };
    }
  }

  isLoggedIn(): boolean {
    return this.keyAuth?.response?.success === true;
  }

  getUserInfo() {
    return this.keyAuth?.response?.info || null;
  }

  logout(): void {
    if (this.keyAuth) {
      this.keyAuth.response = null;
    }
  }
}

export const keyAuthService = KeyAuthService.getInstance();
