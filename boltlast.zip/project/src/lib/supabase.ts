import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface UserData {
  id?: string;
  license_key: string;
  home_team_name: string;
  home_team_score: number;
  away_team_name: string;
  away_team_score: number;
  home_team_logo: string;
  away_team_logo: string;
  created_at?: string;
  updated_at?: string;
}

export async function saveUserData(data: UserData) {
  const { data: existing } = await supabase
    .from('user_data')
    .select('id')
    .eq('license_key', data.license_key)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from('user_data')
      .update({
        ...data,
        updated_at: new Date().toISOString(),
      })
      .eq('license_key', data.license_key);

    return { error };
  } else {
    const { error } = await supabase
      .from('user_data')
      .insert(data);

    return { error };
  }
}

export async function loadUserData(licenseKey: string): Promise<UserData | null> {
  const { data, error } = await supabase
    .from('user_data')
    .select('*')
    .eq('license_key', licenseKey)
    .maybeSingle();

  if (error || !data) return null;
  return data as UserData;
}
